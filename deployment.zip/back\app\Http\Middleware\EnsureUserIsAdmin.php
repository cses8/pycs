<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureUserIsAdmin
{
	/**
	 * @param Closure(Request): Response $next
	 */
	public function handle(Request $request, Closure $next): Response
	{
		if (! $request->user() || ! $request->user()->isAdmin()) {
			abort(Response::HTTP_FORBIDDEN, 'Administrator access is required.');
		}

		return $next($request);
	}
}
