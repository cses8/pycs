import{f as s,c as o,o as a}from"./D4HnjyJA.js";const t=s({__name:"index",setup:s=>(s,t)=>(a(),o("div",null,"this is school-operation"))});export{t as default};
