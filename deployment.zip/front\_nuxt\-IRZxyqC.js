import{aa as a}from"./D4HnjyJA.js";const s=(s="")=>`${a().public.backendBase}${s}`;export{s as a};
