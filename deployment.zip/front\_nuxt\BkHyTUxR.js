import{aL as o,r as e}from"./DXALhGat.js";const r=o("SchoolYear",(()=>({selectedSchoolYear:e({id:0,description:""})})));export{r as u};
