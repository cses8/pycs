import{f as s,c as a,o as e}from"./DXALhGat.js";const i=s({__name:"index",setup:s=>(s,i)=>(e(),a("div",null,"this is academics page"))});export{i as default};
