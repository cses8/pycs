<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateGalleryRequest extends FormRequest
{
	/**
	 * Determine if the user is authorized to make this request.
	 */
	public function authorize(): bool
	{
		return $this->user()?->isAdmin() === true;
	}

	/**
	 * Get the validation rules that apply to the request.
	 *
	 * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
	 */
	public function rules(): array
	{
		return [
			'school_year_id' => ['nullable', 'integer', 'exists:school_years,id'],
			'title' => 'required|string|max:255',
			'description' => 'required|string',
			'start' => 'required|date|before_or_equal:end',
			'end' => 'required|date|after_or_equal:start',
		];
	}
}
