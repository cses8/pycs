import{aL as o,r as e}from"./D4HnjyJA.js";const r=o("SchoolYear",(()=>({selectedSchoolYear:e({id:0,description:""})})));export{r as u};
