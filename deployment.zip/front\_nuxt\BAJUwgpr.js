const r=(r,t)=>{if(!Number.isFinite(r)||!Number.isFinite(t))return 0;const e=Math.ceil(r),i=Math.floor(t);return Math.floor(Math.random()*(i-e+1))+e};export{r};
