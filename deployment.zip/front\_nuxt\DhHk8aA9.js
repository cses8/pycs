import{aa as a}from"./DXALhGat.js";const s=(s="")=>`${a().public.backendBase}${s}`;export{s as a};
