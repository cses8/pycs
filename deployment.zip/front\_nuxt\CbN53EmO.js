import{f as s,o as a,c as t}from"./DXALhGat.js";const e=s({__name:"index",setup:s=>(s,e)=>(a(),t("div",null,"this is about page"))});export{e as default};
